﻿using System;
using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Enemies.Reaction
{
    [CreateAssetMenu(menuName = "JoyJoey/Enemies/Armour Profile", fileName = "EnemyArmourProfile")]
    public class EnemyArmourProfile : ScriptableObject
    {
        public float maxArmour = 100f;
        public float regenDelay = 2f;
        public float regenPerSecond = 5f;
        public ReactionTierMapping[] thresholds;
        public float stunGate = 35f;
        public bool resetOnGround = true;
    }

    [Serializable]
    public struct ReactionTierMapping
    {
        public float minValue;
        public ReactionTier tier;
    }
}
