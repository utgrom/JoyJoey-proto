﻿using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Enemies.Reaction
{
    public class EnemyReactionController : MonoBehaviour
    {
        [SerializeField] private EnemyArmourProfile profile;
        [SerializeField] private float currentArmour;
        [SerializeField] private ReactionTier currentTier = ReactionTier.NoFlinch;

        private float _regenTimer;
        private ReactionTier? _armorCapTier;
        private float _armorBreakThreshold;

        private void Awake()
        {
            currentArmour = profile != null ? profile.maxArmour : 100f;
        }

        private void Update()
        {
            HandleRegeneration(Time.deltaTime);
        }

        public void SetArmorCap(ReactionTier? capTier, float breakThreshold)
        {
            _armorCapTier = capTier;
            _armorBreakThreshold = breakThreshold;
        }

        public ReactionTier ApplyHit(AttackImpact impact)
        {
            if (profile == null)
            {
                return ReactionTier.NoFlinch;
            }

            var arm = currentArmour;
            bool armourBroken;
            var tier = ReactionResolver.Resolve(ref arm, profile, impact, _armorCapTier, _armorBreakThreshold, currentTier, out armourBroken);

            currentArmour = Mathf.Clamp(arm, 0f, profile.maxArmour);
            currentTier = tier;
            _regenTimer = profile.regenDelay;

            return tier;
        }

        public void OnKnockedDown()
        {
            if (profile != null && profile.resetOnGround)
            {
                currentArmour = profile.maxArmour;
            }

            currentTier = ReactionTier.NoFlinch;
        }

        private void HandleRegeneration(float deltaTime)
        {
            if (profile == null)
            {
                return;
            }

            if (_regenTimer > 0f)
            {
                _regenTimer -= deltaTime;
                return;
            }

            if (currentArmour < profile.maxArmour)
            {
                currentArmour = Mathf.Min(profile.maxArmour, currentArmour + profile.regenPerSecond * deltaTime);
            }
        }
    }
}
