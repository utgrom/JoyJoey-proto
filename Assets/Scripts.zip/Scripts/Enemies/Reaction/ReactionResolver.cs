﻿using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Enemies.Reaction
{
    public readonly struct AttackImpact
    {
        public float Break { get; }
        public ReactionTier MinimumTier { get; }
        public Vector2 LaunchPower { get; }
        public bool ForceLaunch { get; }
        public bool IsLauncher => LaunchPower.sqrMagnitude > 0.01f || ForceLaunch;

        public AttackImpact(float breakValue, ReactionTier minTier, Vector2 launchPower, bool forceLaunch)
        {
            Break = breakValue;
            MinimumTier = minTier;
            LaunchPower = launchPower;
            ForceLaunch = forceLaunch;
        }
    }

    public static class ReactionResolver
    {
        public static ReactionTier Resolve(ref float armour, EnemyArmourProfile profile, AttackImpact impact, ReactionTier? armorCapTier, float armorBreakThreshold, ReactionTier currentTier, out bool armourBroken)
        {
            armourBroken = false;

            armour -= impact.Break;
            var tierCandidate = profile != null ? EvaluateTier(armour, profile.thresholds) : ReactionTier.NoFlinch;
            if (tierCandidate < impact.MinimumTier)
            {
                tierCandidate = impact.MinimumTier;
            }

            if (armorCapTier.HasValue && tierCandidate > armorCapTier.Value)
            {
                if (impact.Break >= armorBreakThreshold)
                {
                    tierCandidate = (ReactionTier)Mathf.Min((int)armorCapTier.Value + 1, (int)tierCandidate);
                    armourBroken = true;
                }
                else
                {
                    tierCandidate = armorCapTier.Value;
                }
            }

            if (profile != null && armour <= profile.stunGate)
            {
                if (impact.IsLauncher)
                {
                    tierCandidate = ReactionTier.Launch;
                }
                else if (tierCandidate < ReactionTier.Stagger)
                {
                    tierCandidate = ReactionTier.Stagger;
                }
            }

            if (profile != null && armour < 0f)
            {
                armour = 0f;
            }

            return tierCandidate;
        }

        private static ReactionTier EvaluateTier(float armour, ReactionTierMapping[] mappings)
        {
            if (mappings == null || mappings.Length == 0)
            {
                return ReactionTier.NoFlinch;
            }

            ReactionTier tier = ReactionTier.NoFlinch;

            for (int i = 0; i < mappings.Length; ++i)
            {
                if (armour <= mappings[i].minValue)
                {
                    tier = mappings[i].tier;
                }
            }

            return tier;
        }
    }
}
