﻿using System.Collections.Generic;
using UnityEngine;

namespace JoyJoey.Combat.Attacks
{
    public class HurtboxController : MonoBehaviour
    {
        [SerializeField] private List<Collider2D> hurtboxColliders = new List<Collider2D>();

        public void SetInvulnerable(bool invulnerable, LayerMask ignoreMask)
        {
            foreach (var col in hurtboxColliders)
            {
                if (col == null)
                {
                    continue;
                }

                col.enabled = !invulnerable;
            }

            // Extend here to modify physics layers / filters with ignoreMask if required.
        }
    }
}
