using System;
using System.Collections.Generic;
using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Combat.Attacks
{
    [Serializable]
    public class HitboxProperties
    {
        public Vector2 offset = Vector2.zero;
        public Vector2 size = new Vector2(1f, 1f);
        public float rotation;
        public LayerMask targetMask;
        public float damage = 10f;
        public float breakValue = 10f;
        public bool otg = false;
    }

    [Serializable]
    public class HitboxTimelineEvent
    {
        public string slotId = "Main";
        public int startFrame;
        public int endFrame;
        public HitboxProperties properties = new HitboxProperties();
    }

    [Serializable]
    public class InvulnerabilityWindow
    {
        public int startFrame;
        public int endFrame;
        public LayerMask ignoreLayers;
    }

    [Serializable]
    public class AttackTimeline
    {
        [Range(0, 180)] public int startupFrames = 12;
        [Range(0, 180)] public int activeFrames = 6;
        [Range(0, 180)] public int recoveryFrames = 12;
        [Range(1, 120)] public int framesPerSecond = 60;
        public List<HitboxTimelineEvent> hitboxEvents = new List<HitboxTimelineEvent>();
        public List<InvulnerabilityWindow> invulnerability = new List<InvulnerabilityWindow>();
    }

    [CreateAssetMenu(menuName = "JoyJoey/Combat/Attack Data", fileName = "AttackData")]
    public class AttackData : ScriptableObject
    {
        public AttackTimeline timeline = new AttackTimeline();
        public float hitstopMs = 40f;
        public float baseDamage = 10f;
        public float breakValue = 10f;
        public ReactionTier minimumReactionTier = ReactionTier.NoFlinch;
        public Vector2 launchVector = new Vector2(0f, 10f);
        public bool carryMomentum = false;
        public bool consumeDashCarry = false;
    }
}

