using System;
using System.Collections.Generic;
using JoyJoey.Player.Transformations;
using UnityEngine;

namespace JoyJoey.Combat.Attacks
{
    public class AttackExecutor : MonoBehaviour
    {
        [SerializeField] private List<HitboxSlot> hitboxSlots = new List<HitboxSlot>();
        [SerializeField] private HurtboxController hurtboxController;
        [SerializeField] private TransformManager transformManager;

        private readonly Dictionary<string, HitboxSlot> _slotLookup = new Dictionary<string, HitboxSlot>();
        private readonly List<RuntimeHitboxEvent> _runtimeEvents = new List<RuntimeHitboxEvent>();

        private AttackData _currentAttack;
        private float _currentFrame;
        private bool _isActive;
        private int _attackInstanceId;
        private float _activeHitboxScale = 1f;

        public event Action<AttackData> AttackCompleted;

        private void Awake()
        {
            _slotLookup.Clear();
            foreach (var slot in hitboxSlots)
            {
                if (slot == null || string.IsNullOrEmpty(slot.SlotId))
                {
                    continue;
                }

                if (!_slotLookup.ContainsKey(slot.SlotId))
                {
                    _slotLookup.Add(slot.SlotId, slot);
                }
            }

            transformManager ??= GetComponentInParent<TransformManager>();
        }

        private void Update()
        {
            if (!_isActive || _currentAttack == null)
            {
                return;
            }

            var timeline = _currentAttack.timeline;
            _currentFrame += Time.deltaTime * timeline.framesPerSecond;

            UpdateHitboxes();
            UpdateInvulnerability();

            var totalFrames = timeline.startupFrames + timeline.activeFrames + timeline.recoveryFrames;
            if (_currentFrame >= totalFrames)
            {
                StopAttack(true);
            }
        }

        public void PlayAttack(AttackData attackData)
        {
            if (attackData == null)
            {
                return;
            }

            StopAttack(false);

            _attackInstanceId++;
            _currentAttack = attackData;
            _currentFrame = 0f;
            _isActive = true;
            _activeHitboxScale = transformManager != null ? Mathf.Max(0.01f, transformManager.HitboxScale) : 1f;

            _runtimeEvents.Clear();

            foreach (var evt in attackData.timeline.hitboxEvents)
            {
                if (!_slotLookup.TryGetValue(evt.slotId, out var slot))
                {
                    continue;
                }

                _runtimeEvents.Add(new RuntimeHitboxEvent
                {
                    definition = evt,
                    slot = slot,
                    isActive = false
                });
            }
        }

        public void CancelAttack()
        {
            StopAttack(true);
        }

        private void UpdateHitboxes()
        {
            for (int i = 0; i < _runtimeEvents.Count; ++i)
            {
                var runtime = _runtimeEvents[i];
                var def = runtime.definition;

                if (!runtime.isActive && _currentFrame >= def.startFrame && _currentFrame <= def.endFrame)
                {
                    runtime.slot.Activate(def.properties, _attackInstanceId, _activeHitboxScale);
                    runtime.isActive = true;
                }
                else if (runtime.isActive && _currentFrame > def.endFrame)
                {
                    runtime.slot.Deactivate();
                    runtime.isActive = false;
                }
            }
        }

        private void UpdateInvulnerability()
        {
            if (hurtboxController == null || _currentAttack == null)
            {
                return;
            }

            bool invulnerable = false;
            LayerMask mask = default;

            foreach (var window in _currentAttack.timeline.invulnerability)
            {
                if (_currentFrame >= window.startFrame && _currentFrame <= window.endFrame)
                {
                    invulnerable = true;
                    mask = window.ignoreLayers;
                    break;
                }
            }

            hurtboxController.SetInvulnerable(invulnerable, mask);
        }

        private void StopAttack(bool notify)
        {
            var finishedAttack = _currentAttack;

            for (int i = 0; i < _runtimeEvents.Count; ++i)
            {
                if (_runtimeEvents[i].isActive)
                {
                    _runtimeEvents[i].slot.Deactivate();
                    _runtimeEvents[i].isActive = false;
                }
            }

            if (hurtboxController != null)
            {
                hurtboxController.SetInvulnerable(false, default);
            }

            _currentAttack = null;
            _isActive = false;

            if (notify && finishedAttack != null)
            {
                AttackCompleted?.Invoke(finishedAttack);
            }
        }

        private sealed class RuntimeHitboxEvent
        {
            public HitboxTimelineEvent definition;
            public HitboxSlot slot;
            public bool isActive;
        }
    }
}

