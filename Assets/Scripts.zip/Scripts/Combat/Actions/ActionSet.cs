using System;
using System.Collections.Generic;
using JoyJoey.Core;
using JoyJoey.Core.Abilities;
using JoyJoey.Combat.Attacks;
using UnityEngine;

namespace JoyJoey.Combat.Actions
{
    [Serializable]
    public class ActionVariant
    {
        public ActionDirection direction = ActionDirection.Neutral;
        [Tooltip("Base attack when no level upgrades are present.")]
        public AttackData attackData;
        [Tooltip("Ability unlock key required for this action. Leave empty if always available.")]
        public string requiredAbilityId = AbilityIds.None;
        [Tooltip("Ability key that selects which version of the attack to use based on its level.")]
        public string levelAbilityId = AbilityIds.None;
        [Tooltip("Optional level-based overrides. Index 0 = ability level 1, index 1 = ability level 2, etc.")]
        public AttackData[] levelVariants = Array.Empty<AttackData>();
    }

    [CreateAssetMenu(menuName = "JoyJoey/Combat/Action Set", fileName = "ActionSet")]
    public class ActionSet : ScriptableObject
    {
        [SerializeField] private List<ActionVariant> variants = new List<ActionVariant>();

        public AttackData Resolve(ActionDirection direction, AbilityUnlockManager abilityManager)
        {
            for (int i = 0; i < variants.Count; ++i)
            {
                var variant = variants[i];
                if (variant.direction != direction || variant.attackData == null)
                {
                    continue;
                }

                if (!IsAbilityMet(variant, abilityManager))
                {
                    continue;
                }

                return ResolveVersion(variant, abilityManager);
            }

            return null;
        }

        private static bool IsAbilityMet(ActionVariant variant, AbilityUnlockManager abilityManager)
        {
            if (variant == null)
            {
                return false;
            }

            if (abilityManager == null || string.IsNullOrEmpty(variant.requiredAbilityId) || variant.requiredAbilityId == AbilityIds.None)
            {
                return true;
            }

            if (!abilityManager.CanUse(variant.requiredAbilityId))
            {
                return false;
            }

            return true;
        }

        private static AttackData ResolveVersion(ActionVariant variant, AbilityUnlockManager abilityManager)
        {
            if (abilityManager == null || string.IsNullOrEmpty(variant.levelAbilityId) || variant.levelAbilityId == AbilityIds.None)
            {
                return variant.attackData;
            }

            int level = Mathf.Max(abilityManager.GetLevel(variant.levelAbilityId), 0);
            if (level <= 0 || variant.levelVariants == null || variant.levelVariants.Length == 0)
            {
                return variant.attackData;
            }

            int index = Mathf.Min(level - 1, variant.levelVariants.Length - 1);
            var upgraded = variant.levelVariants[index];
            return upgraded != null ? upgraded : variant.attackData;
        }
    }
}
