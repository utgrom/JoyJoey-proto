﻿using UnityEngine;

namespace JoyJoey.Combat.Attacks
{
    [RequireComponent(typeof(Collider2D))]
    public class HitboxSlot : MonoBehaviour
    {
        [SerializeField] private string slotId = "Main";
        [SerializeField] private Collider2D collider2D;

        private int _attackInstanceId;

        public string SlotId => slotId;

        private void Reset()
        {
            collider2D = GetComponent<Collider2D>();
            collider2D.isTrigger = true;
        }

        private void Awake()
        {
            if (collider2D == null)
            {
                collider2D = GetComponent<Collider2D>();
            }

            if (collider2D != null)
            {
                collider2D.isTrigger = true;
                collider2D.enabled = false;
            }
        }

        public void Activate(HitboxProperties properties, int attackInstanceId, float scale)
        {
            _attackInstanceId = attackInstanceId;

            var scaledOffset = properties.offset * scale;

            if (collider2D is BoxCollider2D box)
            {
                box.size = properties.size * scale;
                box.offset = scaledOffset;
            }
            else if (collider2D is CircleCollider2D circle)
            {
                circle.radius = properties.size.x * 0.5f * scale;
                circle.offset = scaledOffset;
            }

            collider2D.enabled = true;
        }

        public void Deactivate()
        {
            if (collider2D != null)
            {
                collider2D.enabled = false;
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (!collider2D.enabled)
            {
                return;
            }

            // Hook: route to damage resolver / reaction controller.
        }

        private void OnDrawGizmosSelected()
        {
            if (collider2D == null || !collider2D.enabled)
            {
                return;
            }

            Gizmos.color = Color.red;

            if (collider2D is BoxCollider2D box)
            {
                var matrix = Gizmos.matrix;
                Gizmos.matrix = transform.localToWorldMatrix;
                Gizmos.DrawWireCube(box.offset, box.size);
                Gizmos.matrix = matrix;
            }
            else if (collider2D is CircleCollider2D circle)
            {
                Gizmos.DrawWireSphere(transform.TransformPoint(circle.offset), circle.radius);
            }
        }
    }
}
