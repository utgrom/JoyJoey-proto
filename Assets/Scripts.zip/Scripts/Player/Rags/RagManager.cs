using System;
using System.Collections.Generic;
using JoyJoey.Core.Abilities;
using UnityEngine;

namespace JoyJoey.Player.Rags
{
    public class RagManager : MonoBehaviour
    {
        [SerializeField] private AbilityUnlockManager abilityManager;
        [SerializeField] private List<RagProfile> ragProfiles = new List<RagProfile>();
        [SerializeField] private string startingRagId;

        private int _currentIndex = -1;

        public event Action<RagProfile> RagChanged;

        public RagProfile CurrentRag => (_currentIndex >= 0 && _currentIndex < ragProfiles.Count) ? ragProfiles[_currentIndex] : null;

        private void Awake()
        {
            abilityManager ??= GetComponent<AbilityUnlockManager>();
            InitializeStartingRag();
        }

        private void InitializeStartingRag()
        {
            if (ragProfiles.Count == 0)
            {
                _currentIndex = -1;
                return;
            }

            if (!string.IsNullOrEmpty(startingRagId))
            {
                for (int i = 0; i < ragProfiles.Count; ++i)
                {
                    if (ragProfiles[i] != null && ragProfiles[i].RagId == startingRagId && IsRagUnlocked(ragProfiles[i]))
                    {
                        SetCurrentIndex(i);
                        return;
                    }
                }
            }

            // Fallback to first unlocked rag
            for (int i = 0; i < ragProfiles.Count; ++i)
            {
                if (ragProfiles[i] != null && IsRagUnlocked(ragProfiles[i]))
                {
                    SetCurrentIndex(i);
                    return;
                }
            }

            _currentIndex = -1;
        }

        public void SelectNextRag()
        {
            if (ragProfiles.Count == 0)
            {
                return;
            }

            var next = FindNextIndex(_currentIndex, 1);
            if (next >= 0)
            {
                SetCurrentIndex(next);
            }
        }

        public void SelectPreviousRag()
        {
            if (ragProfiles.Count == 0)
            {
                return;
            }

            var prev = FindNextIndex(_currentIndex, -1);
            if (prev >= 0)
            {
                SetCurrentIndex(prev);
            }
        }

        public void SetRagById(string ragId)
        {
            if (string.IsNullOrEmpty(ragId))
            {
                return;
            }

            for (int i = 0; i < ragProfiles.Count; ++i)
            {
                var profile = ragProfiles[i];
                if (profile != null && profile.RagId == ragId && IsRagUnlocked(profile))
                {
                    SetCurrentIndex(i);
                    break;
                }
            }
        }

        private int FindNextIndex(int startIndex, int direction)
        {
            if (ragProfiles.Count == 0)
            {
                return -1;
            }

            var count = ragProfiles.Count;
            var index = startIndex;

            for (int attempts = 0; attempts < count; ++attempts)
            {
                index = (index + direction + count) % count;
                var profile = ragProfiles[index];
                if (profile != null && IsRagUnlocked(profile))
                {
                    return index;
                }
            }

            return -1;
        }

        private void SetCurrentIndex(int index)
        {
            if (index == _currentIndex)
            {
                return;
            }

            _currentIndex = index;
            RagChanged?.Invoke(CurrentRag);
        }

        private bool IsRagUnlocked(RagProfile profile)
        {
            if (profile == null)
            {
                return false;
            }

            if (abilityManager == null || string.IsNullOrEmpty(profile.UnlockAbilityId) || profile.UnlockAbilityId == AbilityIds.None)
            {
                return true;
            }

            if (!abilityManager.CanUse(profile.UnlockAbilityId))
            {
                return false;
            }

            if (profile.UnlockRequiredLevel <= 0)
            {
                return true;
            }

            return abilityManager.GetLevel(profile.UnlockAbilityId) >= profile.UnlockRequiredLevel;
        }

        public IReadOnlyList<RagProfile> RagProfiles => ragProfiles;
    }
}

