using JoyJoey.Combat.Actions;
using JoyJoey.Player.Transformations;
using UnityEngine;

namespace JoyJoey.Player.Rags
{
    [CreateAssetMenu(menuName = "JoyJoey/Rags/Rag Profile", fileName = "RagProfile")]
    public class RagProfile : ScriptableObject
    {
        [SerializeField] private string ragId = "RagId";
        [SerializeField] private string displayName = "Rag";
        [TextArea] [SerializeField] private string description;
        [SerializeField] private ActionSet specialAttackGroundActions;
        [SerializeField] private ActionSet specialAttackAirActions;
        [SerializeField] private ActionSet specialSkillGroundActions;
        [SerializeField] private ActionSet specialSkillAirActions;

        [Header("Suit (Transform) Overrides")]
        [SerializeField] private SuitProfile suitProfile;
        [SerializeField] private ActionSet suitNormalGroundActions;
        [SerializeField] private ActionSet suitNormalAirActions;

        [Header("Unlock Settings")]
        [SerializeField] private string unlockAbilityId = JoyJoey.Core.Abilities.AbilityIds.None;
        [SerializeField] private int unlockRequiredLevel = 0;
        [SerializeField] private string transformAbilityId = JoyJoey.Core.Abilities.AbilityIds.None;
        [SerializeField] private int transformRequiredLevel = 0;

        public string RagId => ragId;
        public string DisplayName => displayName;
        public string Description => description;
        public ActionSet SpecialAttackGroundActions => specialAttackGroundActions;
        public ActionSet SpecialAttackAirActions => specialAttackAirActions;
        public ActionSet SpecialSkillGroundActions => specialSkillGroundActions;
        public ActionSet SpecialSkillAirActions => specialSkillAirActions;
        public SuitProfile SuitProfile => suitProfile;
        public ActionSet SuitNormalGroundActions => suitNormalGroundActions;
        public ActionSet SuitNormalAirActions => suitNormalAirActions;
        public string UnlockAbilityId => unlockAbilityId;
        public int UnlockRequiredLevel => unlockRequiredLevel;
        public string TransformAbilityId => transformAbilityId;
        public int TransformRequiredLevel => transformRequiredLevel;
    }
}
