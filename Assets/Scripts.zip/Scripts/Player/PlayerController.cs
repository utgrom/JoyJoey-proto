using JoyJoey.Core;
using JoyJoey.Core.Abilities;
using JoyJoey.Player.Input;
using JoyJoey.Player.Combat;
using JoyJoey.Player.Transformations;
using JoyJoey.Player.Rags;
using UnityEngine;

namespace JoyJoey.Player
{
    [RequireComponent(typeof(PlayerMotor))]
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] private PlayerMotor motor;
        [SerializeField] private PlayerInputReader inputReader;
        [SerializeField] private PlayerStatsProfile baseStatsProfile;
        [SerializeField] private AbilityUnlockManager abilityManager;
        [SerializeField] private RagManager ragManager;
        [SerializeField, Range(30f, 120f)] private float targetFps = 60f;
        [SerializeField, Range(0f, 0.5f)] private float moveDeadZone = 0.1f;

        private PlayerRuntimeStats _runtimeStats;
        private InputBuffer _inputBuffer;
        private PlayerStateMachine _stateMachine;
        private PlayerCombatController combatController;
        private TransformManager transformManager;

        private readonly PlayerGroundedState _groundedState = new PlayerGroundedState();
        private readonly PlayerGroundIdleState _groundIdleState = new PlayerGroundIdleState();
        private readonly PlayerGroundMoveState _groundMoveState = new PlayerGroundMoveState();
        private readonly PlayerAirborneState _airborneState = new PlayerAirborneState();
        private readonly PlayerJumpStartState _jumpStartState = new PlayerJumpStartState();
        private readonly PlayerDashState _dashState = new PlayerDashState();
        private readonly PlayerWallSlideState _wallSlideState = new PlayerWallSlideState();

        private Vector2 _moveInput;
        private MovementContext _movementContext = MovementContext.Ground;
        private InputContextFlags _contextFlags = InputContextFlags.None;
        private string _activeRagId = string.Empty;
        private bool _isTransformed;
        private float _dashCarryTimer;
        private bool _processingBuffered;
        private float _coyoteTimer;
        private int _remainingAirJumps;
        private int _facingDirection = 1;
        // Variable jump tracking
        private bool _jumpHolding;
        private float _jumpHoldTimer;

        public PlayerRuntimeStats RuntimeStats => _runtimeStats;
        public PlayerMotor Motor => motor;
        public InputBuffer InputBuffer => _inputBuffer;
        public MovementContext MovementContext => _movementContext;
        public InputContextFlags ContextFlags => _contextFlags;
        public string ActiveRagId => _activeRagId;
        public bool IsTransformed => _isTransformed;
        public float MoveDeadZone => moveDeadZone;
        public Vector2 MoveInput => _moveInput;
        public bool HasCoyoteTime => _coyoteTimer > 0f;
        public int FacingDirection => _facingDirection;
        public AbilityUnlockManager AbilityManager => abilityManager;

        private const int JumpBufferFrames = 8;
        private const int TransformBufferFrames = 40;

        private void Reset()
        {
            motor = GetComponent<PlayerMotor>();
        }

        private void Awake()
        {
            motor ??= GetComponent<PlayerMotor>();
            inputReader ??= GetComponent<PlayerInputReader>();
            abilityManager ??= GetComponent<AbilityUnlockManager>();
            ragManager ??= GetComponent<RagManager>();
            combatController = GetComponent<PlayerCombatController>();
            transformManager = GetComponent<TransformManager>();

            _runtimeStats = baseStatsProfile != null
                ? baseStatsProfile.CreateRuntimeInstance()
                : new PlayerRuntimeStats();

            _inputBuffer = new InputBuffer();
            _inputBuffer.SetPolicy(InputActionId.Jump, new BufferPolicy(true, JumpBufferFrames, InputBufferConsumeCondition.OnLand, ActionPriority.High));
            _inputBuffer.SetPolicy(InputActionId.Transform, new BufferPolicy(true, TransformBufferFrames, InputBufferConsumeCondition.OnNeutral, ActionPriority.Normal));

            _stateMachine = new PlayerStateMachine(this);
            RegisterStates();

            transformManager?.SetBaseStats(_runtimeStats.Clone());

            if (ragManager != null)
            {
                ragManager.RagChanged += OnRagChanged;
            }
        }

        private void Start()
        {
            _stateMachine.SetInitialState<PlayerGroundedState>();
            ResetCoyoteTimer();

            if (ragManager != null && ragManager.CurrentRag != null)
            {
                _activeRagId = ragManager.CurrentRag.RagId;
            }
        }

        private void OnDestroy()
        {
            if (ragManager != null)
            {
                ragManager.RagChanged -= OnRagChanged;
            }
        }

        private void Update()
        {
            inputReader?.SampleInput(Time.deltaTime);
            _moveInput = inputReader != null ? inputReader.MoveVector : Vector2.zero;

            UpdateFacing();

            if (inputReader != null)
            {
                PlayerInputReader.ButtonEvent evt;
                while (inputReader.TryDequeue(out evt))
                {
                    var signature = BuildSignature(evt.Button, evt.Modifiers);
                    ProcessInputSignature(signature);
                }
            }

            _inputBuffer.Update(Time.deltaTime, targetFps);
            UpdateContextFlags(Time.deltaTime);

            _stateMachine.Tick(Time.deltaTime);
        }

        private void FixedUpdate()
        {
            motor.ManualUpdate(_runtimeStats, _moveInput);
            HandleLandingEvents();
            UpdateVariableJump(Time.fixedDeltaTime);
            _stateMachine.FixedTick(Time.fixedDeltaTime);
            UpdateCoyoteTimer(Time.fixedDeltaTime);
        }

        private void RegisterStates()
        {
            _stateMachine.RegisterState(_groundedState);
            _stateMachine.RegisterState(_groundIdleState);
            _stateMachine.RegisterState(_groundMoveState);
            _stateMachine.RegisterState(_airborneState);
            _stateMachine.RegisterState(_jumpStartState);
            _stateMachine.RegisterState(_dashState);
            _stateMachine.RegisterState(_wallSlideState);
        }

        private void ProcessInputSignature(InputSignature signature)
        {
            if (combatController != null && combatController.TryHandleInput(signature))
            {
                return;
            }

            if (_stateMachine.TryHandleInput(signature))
            {
                return;
            }

            if (signature.Button == InputButton.SwapNext)
            {
                ragManager?.SelectNextRag();
                return;
            }

            if (signature.Button == InputButton.SwapPrevious)
            {
                ragManager?.SelectPreviousRag();
                return;
            }

            if (_processingBuffered)
            {
                return;
            }

            var actionId = signature.Button.ToActionId();
            if (actionId == InputActionId.None)
            {
                return;
            }

            _inputBuffer.Buffer(actionId, signature);
        }

        private void UpdateFacing()
        {
            if (_moveInput.x > moveDeadZone)
            {
                _facingDirection = 1;
            }
            else if (_moveInput.x < -moveDeadZone)
            {
                _facingDirection = -1;
            }
        }

        private InputSignature BuildSignature(InputButton button, InputModifiers modifiers)
        {
            var dirX = Mathf.Abs(_moveInput.x) >= moveDeadZone ? Mathf.RoundToInt(Mathf.Sign(_moveInput.x)) : 0;
            var dirY = Mathf.Abs(_moveInput.y) >= moveDeadZone ? Mathf.RoundToInt(Mathf.Sign(_moveInput.y)) : 0;

            return new InputSignature(
                button,
                dirX,
                dirY,
                _movementContext,
                _contextFlags,
                modifiers,
                _activeRagId,
                _isTransformed);
        }

        private void UpdateContextFlags(float deltaTime)
        {
            if ((_contextFlags & InputContextFlags.DashCarry) != 0)
            {
                _dashCarryTimer -= deltaTime;
                if (_dashCarryTimer <= 0f)
                {
                    _contextFlags &= ~InputContextFlags.DashCarry;
                }
            }
        }

        private void HandleLandingEvents()
        {
            if (motor.IsGrounded && !motor.WasGroundedLastFrame)
            {
                ResetCoyoteTimer();
                _stateMachine.NotifyLanded();
                ConsumeBufferedActions(InputBufferConsumeCondition.OnLand);
                _jumpHolding = false;
            }
        }

        private void UpdateCoyoteTimer(float deltaTime)
        {
            if (!motor.IsGrounded)
            {
                _coyoteTimer = Mathf.Max(0f, _coyoteTimer - deltaTime);
            }
        }

        public void ConsumeBufferedActions(InputBufferConsumeCondition condition)
        {
            while (_inputBuffer.TryConsume(condition, out var action))
            {
                ProcessBufferedAction(action);
            }
        }

        private void ProcessBufferedAction(BufferedAction action)
        {
            _processingBuffered = true;
            _stateMachine.TryHandleInput(action.Signature);
            _processingBuffered = false;
        }

        private void OnRagChanged(RagProfile profile)
        {
            if (transformManager == null)
            {
                _activeRagId = profile != null ? profile.RagId : string.Empty;
            }
        }

        public void SetMovementContext(MovementContext context)
        {
            _movementContext = context;
            combatController?.OnMovementContextChanged(context);
        }

        public void ResetCoyoteTimer()
        {
            _coyoteTimer = _runtimeStats.jump.coyoteTime;
            _remainingAirJumps = GetMaxAirJumps();
        }

        public void EnterNeutralState()
        {
            _stateMachine.NotifyNeutral();
        }

        public void ExecuteJump(){
            motor.ApplyJump(_runtimeStats);
            _jumpHolding = true;
            _jumpHoldTimer = _runtimeStats.jump.maxJumpHoldTime;
            _movementContext = MovementContext.Air;
            _coyoteTimer = 0f;
        }

        public bool TryStartGroundJump(InputSignature signature)
        {
            if (abilityManager != null && !abilityManager.CanUse(AbilityIds.Jump))
            {
                return false;
            }

            if (!motor.IsGrounded && !HasCoyoteTime)
            {
                return false;
            }

            RequestState<PlayerJumpStartState>();
            return true;
        }

        public bool TryStartAirJump(InputSignature signature)
        {
            if (_remainingAirJumps <= 0)
            {
                return false;
            }

            _remainingAirJumps--;
            RequestState<PlayerJumpStartState>();
            return true;
        }

        public bool TryWallJump()
        {
            if (motor.WallSide == 0)
            {
                return false;
            }

            if (abilityManager != null && !abilityManager.CanUse(AbilityIds.WallJump))
            {
                return false;
            }

            motor.PerformWallJump(_runtimeStats.jump.wallJumpHorizontalSpeed, _runtimeStats.jump.wallJumpVerticalSpeed, motor.WallSide);
            _movementContext = MovementContext.Air;
            _coyoteTimer = 0f;
            _remainingAirJumps = Mathf.Max(0, GetMaxAirJumps() - 1);
            ConsumeDashCarryFlag();
            _jumpHolding = false;
            RequestState<PlayerAirborneState>();
            return true;
        }

        public bool TryStartDash(InputSignature signature)
        {
            var abilityId = _movementContext == MovementContext.Air ? AbilityIds.AirDash : AbilityIds.Dash;
            if (abilityManager != null && !abilityManager.CanUse(abilityId))
            {
                return false;
            }

            RequestState<PlayerDashState>();
            return true;
        }

        public bool TryStartTransform(InputSignature signature)
        {
            if (transformManager == null)
            {
                return false;
            }

            return transformManager.RequestTransform();
        }

        public void SetDashContext(bool active)
        {
            if (active)
            {
                _contextFlags |= InputContextFlags.DashCarry;
                _dashCarryTimer = _runtimeStats.dash.TotalDuration + _runtimeStats.dash.carryWindow;
            }
            else
            {
                _dashCarryTimer = _runtimeStats.dash.carryMomentum ? _runtimeStats.dash.carryWindow : 0f;
                if (_dashCarryTimer <= 0f)
                {
                    _contextFlags &= ~InputContextFlags.DashCarry;
                }
            }
        }

        public void ConsumeDashCarryFlag()
        {
            _contextFlags &= ~InputContextFlags.DashCarry;
            _dashCarryTimer = 0f;
        }

        public void SetTransformState(string ragId, bool isTransformed)
        {
            _activeRagId = ragId ?? string.Empty;
            _isTransformed = isTransformed;
        }

        public void OverrideStats(PlayerRuntimeStats stats)
        {
            _runtimeStats = stats;
            _remainingAirJumps = Mathf.Min(_remainingAirJumps, GetMaxAirJumps());
        }

        private int GetMaxAirJumps()
        {
            int max = _runtimeStats.jump.maxAirJumps;
            if (abilityManager != null && abilityManager.CanUse(AbilityIds.AirJump))
            {
                int level = Mathf.Max(abilityManager.GetLevel(AbilityIds.AirJump), 0);
                max += Mathf.Clamp(level, 0, 1);
            }

            return Mathf.Max(0, max);
        }

                        private void UpdateVariableJump(float deltaTime)
        {
            if (motor == null) return;
            if (motor.IsGrounded) { _jumpHolding = false; return; }

            bool holding = inputReader != null && inputReader.IsPressed(InputButton.Jump);
            if (_jumpHolding)
            {
                if (holding)
                {
                    _jumpHoldTimer -= deltaTime;
                    if (_jumpHoldTimer <= 0f)
                    {
                        _jumpHolding = false; // exceeded max hold time -> cut now
                    }
                }
                else
                {
                    _jumpHolding = false; // released early -> cut now
                }
            }

            float vy = motor.Velocity.y;
            if (vy > 0f)
            {
                if (!_jumpHolding)
                {
                    // Cut jump: apply extra gravity while ascending to quickly end the rise
                    vy += Physics2D.gravity.y * (_runtimeStats.jump.jumpCutGravityMultiplier - 1f) * deltaTime;
                    if (vy < -_runtimeStats.jump.maxFallSpeed) vy = -_runtimeStats.jump.maxFallSpeed;
                    motor.SetVerticalVelocity(vy);
                }
                return;
            }

            if (vy < 0f)
            {
                // Faster fall
                vy += Physics2D.gravity.y * (_runtimeStats.jump.fallGravityMultiplier - 1f) * deltaTime;
                if (vy < -_runtimeStats.jump.maxFallSpeed) vy = -_runtimeStats.jump.maxFallSpeed;
                motor.SetVerticalVelocity(vy);
                return;
            }
        }

        private void RequestState<T>() where T : PlayerState
        {
            _stateMachine.ChangeState<T>();
        }
    }
}








