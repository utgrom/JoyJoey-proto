﻿using JoyJoey.Core;

namespace JoyJoey.Player.Input
{
    public static class InputButtonExtensions
    {
        public static InputActionId ToActionId(this InputButton button)
        {
            return button switch
            {
                InputButton.Normal => InputActionId.Normal,
                InputButton.SpecialAttack => InputActionId.SpecialAttack,
                InputButton.SpecialSkill => InputActionId.SpecialSkill,
                InputButton.Jump => InputActionId.Jump,
                InputButton.Dash => InputActionId.Dash,
                InputButton.Transform => InputActionId.Transform,
                InputButton.SwapNext => InputActionId.SwapNext,
                InputButton.SwapPrevious => InputActionId.SwapPrevious,
                _ => InputActionId.None,
            };
        }
    }
}
