﻿using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Player.Input
{
    public readonly struct InputSignature
    {
        public InputButton Button { get; }
        public sbyte DirX { get; }
        public sbyte DirY { get; }
        public MovementContext MovementContext { get; }
        public InputContextFlags ContextFlags { get; }
        public InputModifiers Modifiers { get; }
        public string ActiveRagId { get; }
        public bool IsTransformed { get; }

        public static InputSignature Empty => new InputSignature(InputButton.None, 0, 0, MovementContext.Ground, InputContextFlags.None, InputModifiers.None, string.Empty, false);

        public InputSignature(InputButton button, int dirX, int dirY, MovementContext movementContext, InputContextFlags contextFlags, InputModifiers modifiers, string activeRagId, bool isTransformed)
        {
            Button = button;
            DirX = (sbyte)Mathf.Clamp(dirX, -1, 1);
            DirY = (sbyte)Mathf.Clamp(dirY, -1, 1);
            MovementContext = movementContext;
            ContextFlags = contextFlags;
            Modifiers = modifiers;
            ActiveRagId = activeRagId;
            IsTransformed = isTransformed;
        }

        public InputSignature WithContext(MovementContext movementContext, InputContextFlags flags)
        {
            return new InputSignature(Button, DirX, DirY, movementContext, flags, Modifiers, ActiveRagId, IsTransformed);
        }

        public InputSignature WithModifiers(InputModifiers modifiers)
        {
            return new InputSignature(Button, DirX, DirY, MovementContext, ContextFlags, modifiers, ActiveRagId, IsTransformed);
        }

        public override string ToString()
        {
            return $"btn={Button}, dir=({DirX},{DirY}), ctx={MovementContext}, flags={ContextFlags}, mods={Modifiers}, rag={ActiveRagId}, transformed={IsTransformed}";
        }
    }
}
