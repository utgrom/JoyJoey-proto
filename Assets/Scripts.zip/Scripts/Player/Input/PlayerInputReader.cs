using System;
using System.Collections.Generic;
using JoyJoey.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace JoyJoey.Player.Input
{
    [DefaultExecutionOrder(-50)]
    public class PlayerInputReader : MonoBehaviour
    {
        [Serializable]
        private class ButtonBinding
        {
            public InputButton button = InputButton.None;
            public InputActionReference action;
        }

        [SerializeField] private InputActionReference moveAction;
        [SerializeField] private List<ButtonBinding> buttonBindings = new List<ButtonBinding>();
        [SerializeField, Range(0.05f, 0.5f)] private float holdThreshold = 0.25f;

        private readonly Queue<ButtonEvent> _events = new Queue<ButtonEvent>();
        private readonly List<ButtonTracker> _trackers = new List<ButtonTracker>();
        private readonly System.Collections.Generic.Dictionary<InputButton, bool> _pressed = new System.Collections.Generic.Dictionary<InputButton, bool>();
        private Vector2 _moveVector;

        public struct ButtonEvent
        {
            public InputButton Button;
            public InputModifiers Modifiers;

            public ButtonEvent(InputButton button, InputModifiers modifiers)
            {
                Button = button;
                Modifiers = modifiers;
            }
        }

        public Vector2 MoveVector => _moveVector;

        private void Awake()
        {
            _trackers.Clear();

            foreach (var binding in buttonBindings)
            {
                if (binding.button == InputButton.None || binding.action == null)
                {
                    continue;
                }

                var tracker = new ButtonTracker(this, binding.button, binding.action);
                _trackers.Add(tracker);
                if (!_pressed.ContainsKey(binding.button)) _pressed.Add(binding.button, false);
            }
        }

        private void OnEnable()
        {
            if (moveAction != null)
            {
                moveAction.action.Enable();
            }

            foreach (var tracker in _trackers)
            {
                tracker.Enable();
            }
        }

        private void OnDisable()
        {
            if (moveAction != null)
            {
                moveAction.action.Disable();
            }

            foreach (var tracker in _trackers)
            {
                tracker.Disable();
            }

            _events.Clear();
        }

        public void SampleInput(float deltaTime)
        {
            if (moveAction != null)
            {
                _moveVector = moveAction.action.ReadValue<Vector2>();
            }

            foreach (var tracker in _trackers)
            {
                tracker.Update(deltaTime, holdThreshold);
            }
        }

        public bool TryDequeue(out ButtonEvent evt)
        {
            if (_events.Count > 0)
            {
                evt = _events.Dequeue();
                return true;
            }

            evt = default;
            return false;
        }

        internal void QueueEvent(InputButton button, InputModifiers modifiers)
        {
            _events.Enqueue(new ButtonEvent(button, modifiers));
        }

        public bool IsPressed(InputButton button)
        {
            bool value;
            return _pressed.TryGetValue(button, out value) && value;
        }

                private sealed class ButtonTracker
        {
            private readonly PlayerInputReader _owner;
            private readonly InputButton _button;
            private readonly InputActionReference _reference;

            private bool _isPressed;
            private float _heldTime;
            private bool _holdTriggered;

            public ButtonTracker(PlayerInputReader owner, InputButton button, InputActionReference reference)
            {
                _owner = owner;
                _button = button;
                _reference = reference;
            }

            public void Enable()
            {
                if (_reference == null)
                {
                    return;
                }

                var action = _reference.action;
                action.Enable();
                action.performed += OnPerformed;
                action.canceled += OnCanceled;
            }

            public void Disable()
            {
                if (_reference == null)
                {
                    return;
                }

                var action = _reference.action;
                action.performed -= OnPerformed;
                action.canceled -= OnCanceled;
                action.Disable();
                _isPressed = false;
                _heldTime = 0f;
                _holdTriggered = false;
            }

            public void Update(float deltaTime, float holdThreshold)
            {
                if (!_isPressed || _holdTriggered)
                {
                    return;
                }
                // Only generate Hold events for action buttons (Normal/SpecialAttack/SpecialSkill)
                bool supportsHold = _button == InputButton.Normal || _button == InputButton.SpecialAttack || _button == InputButton.SpecialSkill;
                if (!supportsHold)
                {
                    return;
                }
                _heldTime += deltaTime;
                if (_heldTime >= holdThreshold)
                {
                    _holdTriggered = true;
                    _owner.QueueEvent(_button, InputModifiers.Hold);
                }
            }

            private void OnPerformed(InputAction.CallbackContext context)
            {
                _isPressed = true;
                _heldTime = 0f;
                _holdTriggered = false;
                _owner.QueueEvent(_button, InputModifiers.Tap);
                _owner._pressed[_button] = true;
            }

            private void OnCanceled(InputAction.CallbackContext context)
            {
                _isPressed = false;
                _heldTime = 0f;
                _owner._pressed[_button] = false;
            }
        }
    }
}

