﻿using System;
using System.Collections.Generic;
using JoyJoey.Core;

namespace JoyJoey.Player.Input
{
    public readonly struct BufferedAction
    {
        public InputActionId ActionId { get; }
        public InputSignature Signature { get; }
        public BufferPolicy Policy { get; }
        public ActionPriority Priority => Policy.priority;

        public BufferedAction(InputActionId actionId, in InputSignature signature, BufferPolicy policy)
        {
            ActionId = actionId;
            Signature = signature;
            Policy = policy;
        }
    }

    public readonly struct BufferPolicy
    {
        public readonly bool bufferEnabled;
        public readonly int bufferFrames;
        public readonly InputBufferConsumeCondition consumeOn;
        public readonly ActionPriority priority;

        public BufferPolicy(bool bufferEnabled, int bufferFrames, InputBufferConsumeCondition consumeOn, ActionPriority priority)
        {
            this.bufferEnabled = bufferEnabled;
            this.bufferFrames = bufferFrames;
            this.consumeOn = consumeOn;
            this.priority = priority;
        }
    }

    public sealed class InputBuffer
    {
        private sealed class Entry
        {
            public InputActionId actionId;
            public InputSignature signature;
            public BufferPolicy policy;
            public float framesRemaining;
            public ulong sequence;
        }

        private readonly Dictionary<InputActionId, BufferPolicy> _policyLookup = new Dictionary<InputActionId, BufferPolicy>();
        private readonly List<Entry> _entries = new List<Entry>();
        private ulong _sequenceCounter;

        public event Action<BufferedAction> TimedOut;

        public void SetPolicy(InputActionId actionId, BufferPolicy policy)
        {
            if (actionId == InputActionId.None)
            {
                return;
            }

            _policyLookup[actionId] = policy;
        }

        public bool Buffer(InputActionId actionId, in InputSignature signature)
        {
            if (actionId == InputActionId.None)
            {
                return false;
            }

            if (!_policyLookup.TryGetValue(actionId, out var policy) || !policy.bufferEnabled)
            {
                return false;
            }

            var entry = new Entry
            {
                actionId = actionId,
                signature = signature,
                policy = policy,
                framesRemaining = policy.bufferFrames,
                sequence = ++_sequenceCounter,
            };

            _entries.Add(entry);
            return true;
        }

        public void Update(float deltaTime, float targetFps)
        {
            if (_entries.Count == 0)
            {
                return;
            }

            var frameDelta = deltaTime * targetFps;

            for (int i = _entries.Count - 1; i >= 0; --i)
            {
                var entry = _entries[i];
                entry.framesRemaining -= frameDelta;

                if (entry.framesRemaining <= 0f)
                {
                    var bufferedAction = new BufferedAction(entry.actionId, entry.signature, entry.policy);
                    _entries.RemoveAt(i);

                    if ((entry.policy.consumeOn & InputBufferConsumeCondition.OnTimeout) != 0)
                    {
                        TimedOut?.Invoke(bufferedAction);
                    }
                }
            }
        }

        public bool TryConsume(InputBufferConsumeCondition condition, out BufferedAction action)
        {
            Entry candidate = null;

            for (int i = 0; i < _entries.Count; ++i)
            {
                var entry = _entries[i];
                if ((entry.policy.consumeOn & condition) == 0)
                {
                    continue;
                }

                if (candidate == null ||
                    entry.policy.priority > candidate.policy.priority ||
                    (entry.policy.priority == candidate.policy.priority && entry.sequence > candidate.sequence))
                {
                    candidate = entry;
                }
            }

            if (candidate != null)
            {
                _entries.Remove(candidate);
                action = new BufferedAction(candidate.actionId, candidate.signature, candidate.policy);
                return true;
            }

            action = default;
            return false;
        }

        public bool Contains(InputActionId actionId)
        {
            for (int i = 0; i < _entries.Count; ++i)
            {
                if (_entries[i].actionId == actionId)
                {
                    return true;
                }
            }

            return false;
        }

        public void Clear()
        {
            _entries.Clear();
        }
    }
}
