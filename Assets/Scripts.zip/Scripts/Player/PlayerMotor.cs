﻿using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Player
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class PlayerMotor : MonoBehaviour
    {
        [SerializeField] private Rigidbody2D body;
        [SerializeField] private LayerMask groundLayers = default;
        [SerializeField] private Vector2 groundCheckOffset = new Vector2(0f, -0.6f);
        [SerializeField] private float groundCheckRadius = 0.2f;
        [SerializeField] private float wallCheckDistance = 0.2f;
        [SerializeField] private Vector2 wallCheckOffsetLeft = new Vector2(-0.5f, 0f);
        [SerializeField] private Vector2 wallCheckOffsetRight = new Vector2(0.5f, 0f);
        [SerializeField] private float wallInputThreshold = 0.15f;
        [SerializeField] private float wallSlideMaxFallSpeed = 3f;
        [SerializeField] private bool drawGizmos = true;

        private bool _isDashing;
        private Vector2 _dashVelocity;
        private bool _gravityOverride;
        private float _gravityOverrideScale;

        public bool IsGrounded { get; private set; }
        public bool WasGroundedLastFrame { get; private set; }
        public bool IsTouchingWall { get; private set; }
        public bool IsTouchingWallLeft { get; private set; }
        public bool IsTouchingWallRight { get; private set; }
        public int WallSide { get; private set; } // -1 left, 1 right, 0 none
        public float WallSlideMaxFall => wallSlideMaxFallSpeed;

        public Vector2 Velocity => body != null ? body.linearVelocity : Vector2.zero;

        private void Reset()
        {
            body = GetComponent<Rigidbody2D>();
        }

        public void ManualUpdate(PlayerRuntimeStats stats, Vector2 moveInput)
        {
            if (body == null)
            {
                return;
            }

            body.gravityScale = _gravityOverride ? _gravityOverrideScale : stats.jump.gravityScale;

            WasGroundedLastFrame = IsGrounded;
            IsGrounded = Physics2D.OverlapCircle((Vector2)transform.position + groundCheckOffset, groundCheckRadius, groundLayers);

            UpdateWallChecks(moveInput);

            var velocity = body.linearVelocity;
            velocity.y = Mathf.Max(velocity.y, -stats.jump.maxFallSpeed);
            body.linearVelocity = velocity;
        }

        public void ApplyGroundMovement(float deltaTime, PlayerRuntimeStats stats, float inputX)
        {
            if (body == null)
            {
                return;
            }

            var velocity = body.linearVelocity;
            var targetSpeed = inputX * stats.movement.maxGroundSpeed;
            var acceleration = Mathf.Abs(targetSpeed) < 0.01f ? stats.movement.groundDeceleration : stats.movement.groundAcceleration;
            velocity.x = Mathf.MoveTowards(velocity.x, targetSpeed, acceleration * deltaTime);
            body.linearVelocity = velocity;
        }

        public void ApplyAirMovement(float deltaTime, PlayerRuntimeStats stats, float inputX)
        {
            if (body == null)
            {
                return;
            }

            var velocity = body.linearVelocity;
            var targetSpeed = inputX * stats.movement.maxGroundSpeed;
            var acceleration = Mathf.Abs(targetSpeed) < 0.01f ? stats.movement.airDeceleration : stats.movement.airAcceleration;
            velocity.x = Mathf.MoveTowards(velocity.x, targetSpeed, acceleration * deltaTime);
            body.linearVelocity = velocity;
        }

        public void ApplyJump(PlayerRuntimeStats stats)
        {
            if (body == null)
            {
                return;
            }

            var velocity = body.linearVelocity;
            velocity.y = stats.jump.jumpVelocity;
            body.linearVelocity = velocity;
            IsGrounded = false;
        }

        public void ApplyWallSlide(float maxSlideSpeed)
        {
            if (body == null)
            {
                return;
            }

            var velocity = body.linearVelocity;
            if (velocity.y < -maxSlideSpeed)
            {
                velocity.y = -maxSlideSpeed;
                body.linearVelocity = velocity;
            }
        }

        public void SetVerticalVelocity(float y)
        {
            if (body == null)
            {
                return;
            }

            var v = body.linearVelocity;
            v.y = y;
            body.linearVelocity = v;
        }

        public void SetGravityOverride(bool enabled, float scale = 0f)
        {
            _gravityOverride = enabled;
            _gravityOverrideScale = scale;
        }

        public void PerformWallJump(float horizontalSpeed, float verticalSpeed, int wallSide)
        {
            if (body == null)
            {
                return;
            }

            var direction = Mathf.Clamp(wallSide, -1, 1);
            var velocity = body.linearVelocity;
            velocity.x = horizontalSpeed * -direction;
            velocity.y = verticalSpeed;
            body.linearVelocity = velocity;
            IsGrounded = false;
        }

        public void BeginDash(PlayerRuntimeStats stats, int facingDirection)
        {
            if (body == null)
            {
                return;
            }

            _isDashing = true;
            var sign = Mathf.Sign(facingDirection == 0 ? 1 : facingDirection);
            _dashVelocity = new Vector2(stats.dash.dashSpeed * sign, 0f);

            switch (stats.dash.momentumPolicy)
            {
                case MomentumPolicy.Maintain:
                    _dashVelocity.x = Mathf.Max(Mathf.Abs(body.linearVelocity.x), stats.dash.dashSpeed) * Mathf.Sign(_dashVelocity.x);
                    break;
                case MomentumPolicy.BlendTo:
                    _dashVelocity.x = Mathf.Lerp(body.linearVelocity.x, _dashVelocity.x, 0.5f);
                    break;
                case MomentumPolicy.ZeroOnEnter:
                    body.linearVelocity = Vector2.zero;
                    break;
            }

            body.linearVelocity = _dashVelocity;
        }

        public void EndDash(PlayerRuntimeStats stats)
        {
            if (body == null)
            {
                return;
            }

            if (!_isDashing)
            {
                return;
            }

            _isDashing = false;

            if (stats.dash.momentumPolicy == MomentumPolicy.ZeroOnExit)
            {
                var velocity = body.linearVelocity;
                velocity.x = 0f;
                body.linearVelocity = velocity;
            }
        }

        private void UpdateWallChecks(Vector2 moveInput)
        {
            if (body == null)
            {
                return;
            }

            var inputX = moveInput.x;
            if (Mathf.Abs(inputX) < wallInputThreshold)
            {
                IsTouchingWall = false;
                IsTouchingWallLeft = false;
                IsTouchingWallRight = false;
                WallSide = 0;
                return;
            }

            var direction = Mathf.Sign(inputX);
            var pos = (Vector2)transform.position;

            if (direction < 0f)
            {
                var hit = Physics2D.Raycast(pos + wallCheckOffsetLeft, Vector2.left, wallCheckDistance, groundLayers);
                IsTouchingWallLeft = hit.collider != null;
                IsTouchingWallRight = false;
                IsTouchingWall = IsTouchingWallLeft;
                WallSide = IsTouchingWall ? -1 : 0;
            }
            else
            {
                var hit = Physics2D.Raycast(pos + wallCheckOffsetRight, Vector2.right, wallCheckDistance, groundLayers);
                IsTouchingWallRight = hit.collider != null;
                IsTouchingWallLeft = false;
                IsTouchingWall = IsTouchingWallRight;
                WallSide = IsTouchingWall ? 1 : 0;
            }
        }

        private void OnDrawGizmosSelected()
        {
            if (!drawGizmos)
            {
                return;
            }

            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere((Vector2)transform.position + groundCheckOffset, groundCheckRadius);

            Gizmos.color = Color.blue;
            var pos = (Vector2)transform.position;
            Gizmos.DrawLine(pos + wallCheckOffsetLeft, pos + wallCheckOffsetLeft + Vector2.left * wallCheckDistance);
            Gizmos.DrawLine(pos + wallCheckOffsetRight, pos + wallCheckOffsetRight + Vector2.right * wallCheckDistance);
        }
    }
}


