using System;
using UnityEngine;

namespace JoyJoey.Player.Stats
{
    public class PlayerStatus : MonoBehaviour
    {
        [Header("Health")]
        [SerializeField] private float maxHealth = 100f;
        [SerializeField] private float currentHealth = 100f;

        [Header("Fun Gauge")]
        [SerializeField] private float maxFun = 100f;
        [SerializeField] private float currentFun = 100f;

        [Header("Economy")]
        [SerializeField] private int grace = 0;

        public event Action<float, float> HealthChanged;
        public event Action<float, float> FunChanged;
        public event Action<int> GraceChanged;

        public float MaxHealth => maxHealth;
        public float CurrentHealth => currentHealth;
        public float HealthPercent => maxHealth > 0f ? currentHealth / maxHealth : 0f;

        public float MaxFun => maxFun;
        public float CurrentFun => currentFun;
        public float FunPercent => maxFun > 0f ? currentFun / maxFun : 0f;

        public int Grace => grace;

        private void OnValidate()
        {
            maxHealth = Mathf.Max(1f, maxHealth);
            currentHealth = Mathf.Clamp(currentHealth, 0f, maxHealth);
            maxFun = Mathf.Max(1f, maxFun);
            currentFun = Mathf.Clamp(currentFun, 0f, maxFun);
        }

        public void Initialize(float? overrideHealth = null, float? overrideFun = null)
        {
            if (overrideHealth.HasValue)
            {
                maxHealth = Mathf.Max(1f, overrideHealth.Value);
                currentHealth = maxHealth;
                HealthChanged?.Invoke(currentHealth, maxHealth);
            }

            if (overrideFun.HasValue)
            {
                maxFun = Mathf.Max(1f, overrideFun.Value);
                currentFun = maxFun;
                FunChanged?.Invoke(currentFun, maxFun);
            }
        }

        public void TakeDamage(float amount)
        {
            if (amount <= 0f)
            {
                return;
            }

            currentHealth = Mathf.Max(0f, currentHealth - amount);
            HealthChanged?.Invoke(currentHealth, maxHealth);
        }

        public void Heal(float amount)
        {
            if (amount <= 0f)
            {
                return;
            }

            currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
            HealthChanged?.Invoke(currentHealth, maxHealth);
        }

        public void UpgradeMaxHealth(float amount, bool healToFull = true)
        {
            maxHealth = Mathf.Max(1f, maxHealth + Mathf.Max(0f, amount));

            if (healToFull)
            {
                currentHealth = maxHealth;
            }
            else
            {
                currentHealth = Mathf.Clamp(currentHealth, 0f, maxHealth);
            }

            HealthChanged?.Invoke(currentHealth, maxHealth);
        }

        public void AddFun(float amount)
        {
            if (amount <= 0f)
            {
                return;
            }

            currentFun = Mathf.Min(maxFun, currentFun + amount);
            FunChanged?.Invoke(currentFun, maxFun);
        }

        public bool TryConsumeFun(float amount)
        {
            if (amount <= 0f)
            {
                return currentFun > 0f;
            }

            if (currentFun <= 0f)
            {
                return false;
            }

            currentFun = Mathf.Max(0f, currentFun - amount);
            FunChanged?.Invoke(currentFun, maxFun);
            return currentFun > 0f;
        }

        public void UpgradeMaxFun(float amount, bool refill = true)
        {
            maxFun = Mathf.Max(1f, maxFun + Mathf.Max(0f, amount));

            if (refill)
            {
                currentFun = maxFun;
            }
            else
            {
                currentFun = Mathf.Clamp(currentFun, 0f, maxFun);
            }

            FunChanged?.Invoke(currentFun, maxFun);
        }

        public void SetGrace(int amount)
        {
            grace = Mathf.Max(0, amount);
            GraceChanged?.Invoke(grace);
        }

        public void AddGrace(int amount)
        {
            if (amount == 0)
            {
                return;
            }

            grace = Mathf.Max(0, grace + amount);
            GraceChanged?.Invoke(grace);
        }

        public bool SpendGrace(int amount)
        {
            if (amount <= 0)
            {
                return true;
            }

            if (grace < amount)
            {
                return false;
            }

            grace -= amount;
            GraceChanged?.Invoke(grace);
            return true;
        }
    }
}

