﻿using JoyJoey.Core;
using JoyJoey.Player.Input;

namespace JoyJoey.Player
{
    public abstract class PlayerState
    {
        protected PlayerStateMachine Machine { get; private set; }
        protected PlayerController Controller => Machine.Controller;

        internal void Initialize(PlayerStateMachine machine)
        {
            Machine = machine;
            OnInitialized();
        }

        protected virtual void OnInitialized()
        {
        }

        public virtual void OnEnter(PlayerState previous)
        {
        }

        public virtual void OnExit(PlayerState next)
        {
        }

        public virtual bool TryHandleInput(InputSignature signature)
        {
            return false;
        }

        public virtual void Tick(float deltaTime)
        {
        }

        public virtual void FixedTick(float deltaTime)
        {
        }

        public virtual void OnCancelWindowOpened()
        {
        }

        public virtual void OnLanded()
        {
        }

        public virtual void OnNeutral()
        {
        }

        protected void RequestState<T>() where T : PlayerState
        {
            Machine.ChangeState<T>();
        }

        protected bool ConsumeBufferedAction(InputBufferConsumeCondition condition, out BufferedAction action)
        {
            return Controller.InputBuffer.TryConsume(condition, out action);
        }
    }

    public abstract class PlayerCompositeState : PlayerState
    {
        private PlayerState _subState;

        protected PlayerState ActiveSubState => _subState;

        protected void SetSubState(PlayerState next)
        {
            if (_subState == next)
            {
                return;
            }

            var previous = _subState;
            previous?.OnExit(next);
            _subState = next;
            _subState?.OnEnter(previous);
        }

        protected T GetSubState<T>() where T : PlayerState
        {
            return Machine.GetState<T>();
        }

        public override bool TryHandleInput(InputSignature signature)
        {
            if (base.TryHandleInput(signature))
            {
                return true;
            }

            return _subState != null && _subState.TryHandleInput(signature);
        }

        public override void Tick(float deltaTime)
        {
            base.Tick(deltaTime);
            _subState?.Tick(deltaTime);
        }

        public override void FixedTick(float deltaTime)
        {
            base.FixedTick(deltaTime);
            _subState?.FixedTick(deltaTime);
        }

        public override void OnCancelWindowOpened()
        {
            base.OnCancelWindowOpened();
            _subState?.OnCancelWindowOpened();
        }

        public override void OnLanded()
        {
            base.OnLanded();
            _subState?.OnLanded();
        }

        public override void OnNeutral()
        {
            base.OnNeutral();
            _subState?.OnNeutral();
        }
    }
}
