using JoyJoey.Core;
using UnityEngine;

namespace JoyJoey.Player
{
    public class PlayerWallSlideState : PlayerState
    {
        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.SetMovementContext(MovementContext.Air);
        }

        public override void Tick(float deltaTime)
        {
            base.Tick(deltaTime);

            var motor = Controller.Motor;
            var inputX = Controller.MoveInput.x;
            var pressingIntoWall = Mathf.Abs(inputX) > Controller.MoveDeadZone && Mathf.Sign(inputX) == motor.WallSide;

            if (!motor.IsTouchingWall || motor.IsGrounded || motor.Velocity.y >= 0f || !pressingIntoWall)
            {
                RequestState<PlayerAirborneState>();
                return;
            }
        }

        public override void FixedTick(float deltaTime)
        {
            Controller.Motor.ApplyWallSlide(Controller.Motor.WallSlideMaxFall);
            Controller.Motor.ApplyAirMovement(deltaTime, Controller.RuntimeStats, Controller.MoveInput.x * 0.5f);
        }

        public override bool TryHandleInput(JoyJoey.Player.Input.InputSignature signature)
        {
            if (signature.Button == InputButton.Jump)
            {
                if (Controller.TryWallJump())
                {
                    return true;
                }
            }

            return base.TryHandleInput(signature);
        }
    }
}
