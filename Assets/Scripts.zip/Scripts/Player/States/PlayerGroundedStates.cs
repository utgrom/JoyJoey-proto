﻿using JoyJoey.Core;
using JoyJoey.Player.Input;
using UnityEngine;

namespace JoyJoey.Player
{
    public class PlayerGroundedState : PlayerCompositeState
    {
        private const float MoveThreshold = 0.1f;

        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.SetMovementContext(MovementContext.Ground);
            EvaluateSubState(true);
            Controller.ResetCoyoteTimer();
        }

        public override void Tick(float deltaTime)
        {
            if (!Controller.Motor.IsGrounded && !Controller.HasCoyoteTime)
            {
                RequestState<PlayerAirborneState>();
                return;
            }

            EvaluateSubState(false);
            base.Tick(deltaTime);
        }

        public override bool TryHandleInput(InputSignature signature)
        {
            switch (signature.Button)
            {
                case InputButton.Jump:
                    if (Controller.TryStartGroundJump(signature))
                    {
                        return true;
                    }
                    break;
                case InputButton.Dash:
                    if (Controller.TryStartDash(signature))
                    {
                        return true;
                    }
                    break;
                case InputButton.Transform:
                    if (Controller.TryStartTransform(signature))
                    {
                        return true;
                    }
                    break;
            }

            return base.TryHandleInput(signature);
        }

        public override void OnNeutral()
        {
            base.OnNeutral();
            Controller.ConsumeBufferedActions(InputBufferConsumeCondition.OnNeutral);
        }

        private void EvaluateSubState(bool force)
        {
            var moveX = Controller.MoveInput.x;
            var target = Mathf.Abs(moveX) > MoveThreshold
                ? (PlayerState)GetSubState<PlayerGroundMoveState>()
                : GetSubState<PlayerGroundIdleState>();

            if (force || !ReferenceEquals(target, ActiveSubState))
            {
                SetSubState(target);
            }
        }
    }

    public class PlayerGroundIdleState : PlayerState
    {
        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.EnterNeutralState();
        }

        public override void FixedTick(float deltaTime)
        {
            var motor = Controller.Motor;
            var stats = Controller.RuntimeStats;
            motor.ApplyGroundMovement(deltaTime, stats, 0f);
        }
    }

    public class PlayerGroundMoveState : PlayerState
    {
        public override void FixedTick(float deltaTime)
        {
            var motor = Controller.Motor;
            var stats = Controller.RuntimeStats;
            motor.ApplyGroundMovement(deltaTime, stats, Controller.MoveInput.x);
        }
    }
}
