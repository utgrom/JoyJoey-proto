using JoyJoey.Core;
using JoyJoey.Player.Input;
using UnityEngine;

namespace JoyJoey.Player
{
    public class PlayerAirborneState : PlayerState
    {
        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.SetMovementContext(MovementContext.Air);
        }

        public override void Tick(float deltaTime)
        {
            base.Tick(deltaTime);

            // Transition to wall slide if player is holding into a wall AND is descending
            var motor = Controller.Motor;
            var inputX = Controller.MoveInput.x;
            var pressingIntoWall = Mathf.Abs(inputX) > Controller.MoveDeadZone && Mathf.Sign(inputX) == motor.WallSide;

            if (!motor.IsGrounded && motor.IsTouchingWall && motor.Velocity.y < 0f && pressingIntoWall)
            {
                RequestState<PlayerWallSlideState>();
                return;
            }

            if (Controller.Motor.IsGrounded)
            {
                RequestState<PlayerGroundedState>();
            }
        }

        public override bool TryHandleInput(InputSignature signature)
        {
            if (signature.Button == InputButton.Jump)
            {
                if (Controller.TryStartAirJump(signature))
                {
                    return true;
                }
            }

            if (signature.Button == InputButton.Dash)
            {
                if (Controller.TryStartDash(signature))
                {
                    return true;
                }
            }

            return base.TryHandleInput(signature);
        }

        public override void FixedTick(float deltaTime)
        {
            Controller.Motor.ApplyAirMovement(deltaTime, Controller.RuntimeStats, Controller.MoveInput.x);
        }

        public override void OnLanded()
        {
            base.OnLanded();
            RequestState<PlayerGroundedState>();
        }
    }

    public class PlayerJumpStartState : PlayerState
    {
        private float _timer;
        private const float TransitionDelay = 0.05f;

        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.ExecuteJump();
            _timer = TransitionDelay;
        }

        public override void Tick(float deltaTime)
        {
            base.Tick(deltaTime);
            _timer -= deltaTime;

            if (_timer <= 0f)
            {
                RequestState<PlayerAirborneState>();
            }
        }
    }
}
