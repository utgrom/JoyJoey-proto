using JoyJoey.Player.Input;
using UnityEngine;

namespace JoyJoey.Player
{
    public class PlayerDashState : PlayerState
    {
        private enum Phase
        {
            Startup,
            Active,
            Recovery,
            Complete
        }

        private Phase _phase;
        private float _phaseTimer;
        private bool _dashVelocityApplied;

        public override void OnEnter(PlayerState previous)
        {
            base.OnEnter(previous);
            Controller.SetDashContext(true);
            BeginStartupPhase();
        }

        public override void OnExit(PlayerState next)
        {
            base.OnExit(next);
            if (_dashVelocityApplied)
            {
                Controller.Motor.EndDash(Controller.RuntimeStats);
            }
            Controller.SetDashContext(false);
        }

        public override void Tick(float deltaTime)
        {
            base.Tick(deltaTime);

            if (_phase == Phase.Complete)
            {
                CompleteDash();
                return;
            }

            _phaseTimer -= deltaTime;
            if (_phaseTimer <= 0f)
            {
                AdvancePhase();
            }
        }

        public override bool TryHandleInput(InputSignature signature)
        {
            if (Controller.RuntimeStats.dash.locksInputs && (_phase == Phase.Startup || _phase == Phase.Active))
            {
                return false;
            }

            return base.TryHandleInput(signature);
        }

        private void BeginStartupPhase()
        {
            _phase = Phase.Startup;
            _phaseTimer = Mathf.Max(0f, Controller.RuntimeStats.dash.startupTime);
            _dashVelocityApplied = false;
            if (_phaseTimer <= 0f)
            {
                AdvancePhase();
            }
        }

        private void BeginActivePhase()
        {
            _phase = Phase.Active;
            _phaseTimer = Mathf.Max(0f, Controller.RuntimeStats.dash.activeTime);
            Controller.Motor.BeginDash(Controller.RuntimeStats, Controller.FacingDirection);
            // Disable gravity and lock vertical motion during active dash
            Controller.Motor.SetGravityOverride(true, 0f);
            Controller.Motor.SetVerticalVelocity(0f);
            _dashVelocityApplied = true;
            if (_phaseTimer <= 0f)
            {
                AdvancePhase();
            }
        }

        private void BeginRecoveryPhase()
        {
            _phase = Phase.Recovery;
            _phaseTimer = Mathf.Max(0f, Controller.RuntimeStats.dash.recoveryTime);
            if (_dashVelocityApplied)
            {
                Controller.Motor.EndDash(Controller.RuntimeStats);
                _dashVelocityApplied = false;
            }
            // Restore gravity on recovery
            Controller.Motor.SetGravityOverride(false);
            if (_phaseTimer <= 0f)
            {
                AdvancePhase();
            }
        }

        private void AdvancePhase()
        {
            switch (_phase)
            {
                case Phase.Startup:
                    BeginActivePhase();
                    break;
                case Phase.Active:
                    BeginRecoveryPhase();
                    break;
                case Phase.Recovery:
                    _phase = Phase.Complete;
                    CompleteDash();
                    break;
                default:
                    CompleteDash();
                    break;
            }
        }

        private void CompleteDash()
        {
            if (_phase == Phase.Complete)
            {
                Controller.SetDashContext(false);
                Controller.Motor.SetGravityOverride(false);
                if (Controller.Motor.IsGrounded)
                {
                    RequestState<PlayerGroundedState>();
                }
                else
                {
                    RequestState<PlayerAirborneState>();
                }
            }
        }
    }
}
