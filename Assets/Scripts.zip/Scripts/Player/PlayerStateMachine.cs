﻿using System;
using System.Collections.Generic;
using JoyJoey.Player.Input;

namespace JoyJoey.Player
{
    public sealed class PlayerStateMachine
    {
        private readonly Dictionary<Type, PlayerState> _states = new Dictionary<Type, PlayerState>();
        private PlayerState _currentState;

        public PlayerController Controller { get; }

        public PlayerStateMachine(PlayerController controller)
        {
            Controller = controller;
        }

        public void RegisterState(PlayerState state)
        {
            var type = state.GetType();
            if (_states.ContainsKey(type))
            {
                return;
            }

            state.Initialize(this);
            _states.Add(type, state);
        }

        public T GetState<T>() where T : PlayerState
        {
            return (T)_states[typeof(T)];
        }

        public void SetInitialState<T>() where T : PlayerState
        {
            ChangeState(typeof(T));
        }

        public void ChangeState<T>() where T : PlayerState
        {
            ChangeState(typeof(T));
        }

        public void ChangeState(Type stateType)
        {
            if (!_states.TryGetValue(stateType, out var nextState))
            {
                return;
            }

            if (_currentState == nextState)
            {
                return;
            }

            var previous = _currentState;
            previous?.OnExit(nextState);
            _currentState = nextState;
            _currentState?.OnEnter(previous);
        }

        public bool TryHandleInput(InputSignature signature)
        {
            return _currentState != null && _currentState.TryHandleInput(signature);
        }

        public void Tick(float deltaTime)
        {
            _currentState?.Tick(deltaTime);
        }

        public void FixedTick(float deltaTime)
        {
            _currentState?.FixedTick(deltaTime);
        }

        public void NotifyCancelWindowOpened()
        {
            _currentState?.OnCancelWindowOpened();
        }

        public void NotifyLanded()
        {
            _currentState?.OnLanded();
        }

        public void NotifyNeutral()
        {
            _currentState?.OnNeutral();
        }
    }
}
