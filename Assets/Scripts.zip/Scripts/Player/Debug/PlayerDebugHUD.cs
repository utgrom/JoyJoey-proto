using System.Text;
using JoyJoey.Core;
using JoyJoey.Player.Stats;
using UnityEngine;

namespace JoyJoey.Player.Debug
{
    [DefaultExecutionOrder(1000)]
    public class PlayerDebugHUD : MonoBehaviour
    {
        [SerializeField] private PlayerController controller;
        [SerializeField] private PlayerStatus playerStatus;
        [SerializeField] private bool showHud = true;
        [SerializeField] private Vector2 screenOffset = new Vector2(15f, 15f);
        [SerializeField] private GUIStyle labelStyle;

        private readonly StringBuilder _builder = new StringBuilder(256);

        private void Reset()
        {
            controller = GetComponent<PlayerController>();
            playerStatus = GetComponent<PlayerStatus>();
        }

        private void Awake()
        {
            controller ??= GetComponent<PlayerController>();
            playerStatus ??= GetComponent<PlayerStatus>();

            if (labelStyle == null)
            {
                labelStyle = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 14,
                    normal = { textColor = Color.white }
                };
            }
        }

        private void Update()
        {
            if (UnityEngine.Input.GetKeyDown(KeyCode.F1))
            {
                showHud = !showHud;
            }
        }

        private void OnGUI()
        {
            if (!showHud || controller == null)
            {
                return;
            }

            var motor = controller.Motor;

            _builder.Clear();
            _builder.AppendLine("--- Player Debug ---");
            _builder.Append("Context: ").Append(controller.MovementContext).AppendLine();
            _builder.Append("Rag: ").Append(string.IsNullOrEmpty(controller.ActiveRagId) ? "None" : controller.ActiveRagId);
            _builder.Append(controller.IsTransformed ? " (Transformed)" : string.Empty).AppendLine();
            _builder.Append("Velocity: ").AppendFormat("{0:0.00}, {1:0.00}", motor.Velocity.x, motor.Velocity.y).AppendLine();
            _builder.Append("Grounded: ").Append(motor.IsGrounded).Append(" | Coyote: ").Append(controller.HasCoyoteTime).AppendLine();
            _builder.Append("Wall: ").Append(motor.IsTouchingWall).Append(" (side ").Append(motor.WallSide).Append(")").AppendLine();
            _builder.Append("DashCarry: ").Append((controller.ContextFlags & InputContextFlags.DashCarry) != 0).AppendLine();

            if (playerStatus != null)
            {
                _builder.Append("Health: ").AppendFormat("{0:0.0}/{1:0.0}", playerStatus.CurrentHealth, playerStatus.MaxHealth).AppendLine();
                _builder.Append("Fun: ").AppendFormat("{0:0.0}/{1:0.0}", playerStatus.CurrentFun, playerStatus.MaxFun).AppendLine();
                _builder.Append("Grace: ").Append(playerStatus.Grace).AppendLine();
            }

            GUI.Label(new Rect(screenOffset.x, screenOffset.y, 400f, 220f), _builder.ToString(), labelStyle);
        }
    }
}
