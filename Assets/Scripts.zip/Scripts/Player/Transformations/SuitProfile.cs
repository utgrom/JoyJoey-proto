using UnityEngine;

namespace JoyJoey.Player.Transformations
{
    [CreateAssetMenu(menuName = "JoyJoey/Transformations/Suit Profile", fileName = "SuitProfile")]
    public class SuitProfile : ScriptableObject
    {
        [Header("Stat Multipliers")]
        [SerializeField] private float speedMultiplier = 1f;
        [SerializeField] private float jumpMultiplier = 1f;
        [SerializeField] private float dashSpeedMultiplier = 1f;

        [Header("Visual Overrides")]
        [SerializeField] private Vector3 visualScale = Vector3.one;
        [SerializeField] private float colliderHeightMultiplier = 1f;
        [SerializeField] private float colliderRadiusMultiplier = 1f;
        [SerializeField] private float hitboxScaleMultiplier = 1f;

        [Header("Resource Drain")]
        [SerializeField] private float funDrainPerSecond = 5f;

        public float SpeedMultiplier => speedMultiplier;
        public float JumpMultiplier => jumpMultiplier;
        public float DashSpeedMultiplier => dashSpeedMultiplier;
        public Vector3 VisualScale => visualScale;
        public float ColliderHeightMultiplier => colliderHeightMultiplier;
        public float ColliderRadiusMultiplier => colliderRadiusMultiplier;
        public float HitboxScaleMultiplier => hitboxScaleMultiplier;
        public float FunDrainPerSecond => funDrainPerSecond;
    }
}
