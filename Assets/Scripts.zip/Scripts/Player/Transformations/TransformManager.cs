using JoyJoey.Core;
using JoyJoey.Core.Abilities;
using JoyJoey.Player.Rags;
using JoyJoey.Player.Stats;
using UnityEngine;

namespace JoyJoey.Player.Transformations
{
    [RequireComponent(typeof(PlayerController))]
    public class TransformManager : MonoBehaviour
    {
        [SerializeField] private PlayerController controller;
        [SerializeField] private PlayerStatsProfile baseStatsProfile;
        [SerializeField] private RagManager ragManager;
        [SerializeField] private PlayerStatus playerStatus;
        [SerializeField] private AbilityUnlockManager abilityManager;
        [SerializeField] private float transformThreshold = 25f;

        private PlayerRuntimeStats _baseStats;
        private SuitProfile _activeSuitProfile;
        private bool _isTransformActive;
        private Vector3 _baseVisualScale;
        private CapsuleCollider2D _capsuleCollider;
        private Vector2 _baseColliderSize;
        private Vector2 _baseColliderOffset;
        private float _baseColliderBottom;
        private float _currentHitboxScale = 1f;

        public bool IsTransformActive => _isTransformActive;
        public float HitboxScale => _currentHitboxScale;

        private void Reset()
        {
            controller = GetComponent<PlayerController>();
            ragManager = GetComponent<RagManager>();
            playerStatus = GetComponent<PlayerStatus>();
            abilityManager = GetComponent<AbilityUnlockManager>();
        }

        private void Awake()
        {
            controller ??= GetComponent<PlayerController>();
            ragManager ??= GetComponent<RagManager>();
            playerStatus ??= GetComponent<PlayerStatus>() ?? GetComponentInParent<PlayerStatus>();
            abilityManager ??= GetComponent<AbilityUnlockManager>() ?? GetComponentInParent<AbilityUnlockManager>();

            _baseStats = baseStatsProfile != null ? baseStatsProfile.CreateRuntimeInstance() : controller.RuntimeStats.Clone();
            controller.OverrideStats(_baseStats.Clone());
            _baseVisualScale = controller.transform.localScale;
            _capsuleCollider = GetComponent<CapsuleCollider2D>() ?? GetComponentInChildren<CapsuleCollider2D>();
            if (_capsuleCollider != null)
            {
                _baseColliderSize = _capsuleCollider.size;
                _baseColliderOffset = _capsuleCollider.offset;
                _baseColliderBottom = _baseColliderOffset.y - (_baseColliderSize.y * 0.5f);
            }
            _currentHitboxScale = 1f;

            if (ragManager != null)
            {
                ragManager.RagChanged += OnRagChanged;
            }

            controller.SetTransformState(GetCurrentRagId(), false);
        }

        private void OnDestroy()
        {
            if (ragManager != null)
            {
                ragManager.RagChanged -= OnRagChanged;
            }
        }

        private void Update()
        {
            if (!_isTransformActive || _activeSuitProfile == null || playerStatus == null)
            {
                return;
            }

            if (!HasTransformAbility())
            {
                DeactivateTransform();
                return;
            }

            var drain = _activeSuitProfile.FunDrainPerSecond * Time.deltaTime;
            if (drain <= 0f)
            {
                return;
            }

            if (!playerStatus.TryConsumeFun(drain))
            {
                DeactivateTransform();
            }
        }

        public bool CanTransformNow()
        {
            if (_isTransformActive)
            {
                return false;
            }

            if (!HasTransformAbility())
            {
                return false;
            }

            if (playerStatus == null || playerStatus.CurrentFun < transformThreshold)
            {
                return false;
            }

            return GetCurrentSuitProfile() != null;
        }

        public bool RequestTransform()
        {
            if (_isTransformActive)
            {
                DeactivateTransform();
                return true;
            }

            if (!CanTransformNow())
            {
                return false;
            }

            return ActivateCurrentRagSuit();
        }

        public void DeactivateTransform()
        {
            if (!_isTransformActive)
            {
                return;
            }

            _isTransformActive = false;
            _activeSuitProfile = null;
            controller.SetTransformState(GetCurrentRagId(), false);
            controller.OverrideStats(_baseStats.Clone());
            ResetVisualOverrides();
        }

        public void SetBaseStats(PlayerRuntimeStats stats)
        {
            _baseStats = stats.Clone();
            if (!_isTransformActive)
            {
                controller.OverrideStats(_baseStats.Clone());
            }
        }

        private bool ActivateCurrentRagSuit()
        {
            var suit = GetCurrentSuitProfile();
            if (suit == null)
            {
                return false;
            }

            ApplySuitStats(suit);
            _activeSuitProfile = suit;
            _isTransformActive = true;
            controller.SetTransformState(GetCurrentRagId(), true);
            return true;
        }

        private SuitProfile GetCurrentSuitProfile()
        {
            return ragManager != null && ragManager.CurrentRag != null ? ragManager.CurrentRag.SuitProfile : null;
        }

        private string GetCurrentRagId()
        {
            return ragManager != null && ragManager.CurrentRag != null ? ragManager.CurrentRag.RagId : string.Empty;
        }

        private bool HasTransformAbility()
        {
            var rag = ragManager != null ? ragManager.CurrentRag : null;
            if (rag == null)
            {
                return false;
            }

            var abilityId = rag.TransformAbilityId;
            if (string.IsNullOrEmpty(abilityId) || abilityId == AbilityIds.None)
            {
                return true;
            }

            if (abilityManager == null || !abilityManager.CanUse(abilityId))
            {
                return false;
            }

            if (rag.TransformRequiredLevel > 0 && abilityManager.GetLevel(abilityId) < rag.TransformRequiredLevel)
            {
                return false;
            }

            return true;
        }

        private void ApplySuitStats(SuitProfile suit)
        {
            var stats = _baseStats.Clone();
            stats.movement.maxGroundSpeed *= suit.SpeedMultiplier;
            stats.movement.groundAcceleration *= suit.SpeedMultiplier;
            stats.movement.groundDeceleration *= suit.SpeedMultiplier;
            stats.movement.airAcceleration *= suit.SpeedMultiplier;
            stats.movement.airDeceleration *= suit.SpeedMultiplier;

            stats.jump.jumpVelocity *= suit.JumpMultiplier;
            stats.jump.maxFallSpeed *= suit.JumpMultiplier;

            stats.dash.dashSpeed *= suit.DashSpeedMultiplier;

            controller.OverrideStats(stats);
            ApplyVisualOverrides(suit);
        }

        private void OnRagChanged(RagProfile profile)
        {
            controller.SetTransformState(profile != null ? profile.RagId : string.Empty, _isTransformActive);

            if (_isTransformActive)
            {
                if (!HasTransformAbility())
                {
                    DeactivateTransform();
                    return;
                }

                var suit = GetCurrentSuitProfile();
                if (suit != null)
                {
                    ApplySuitStats(suit);
                    _activeSuitProfile = suit;
                }
                else
                {
                    DeactivateTransform();
                }
            }
        }

        private void ApplyVisualOverrides(SuitProfile suit)
        {
            controller.transform.localScale = Vector3.Scale(_baseVisualScale, suit.VisualScale);

            if (_capsuleCollider != null)
            {
                var size = _baseColliderSize;
                size.y *= suit.ColliderHeightMultiplier;
                size.x *= suit.ColliderRadiusMultiplier;
                _capsuleCollider.size = size;

                var offset = _baseColliderOffset;
                offset.y = _baseColliderBottom + (size.y * 0.5f);
                _capsuleCollider.offset = offset;
            }

            _currentHitboxScale = Mathf.Max(0.01f, suit.HitboxScaleMultiplier);
        }

        private void ResetVisualOverrides()
        {
            controller.transform.localScale = _baseVisualScale;

            if (_capsuleCollider != null)
            {
                _capsuleCollider.size = _baseColliderSize;
                _capsuleCollider.offset = _baseColliderOffset;
            }

            _currentHitboxScale = 1f;
        }
    }
}
