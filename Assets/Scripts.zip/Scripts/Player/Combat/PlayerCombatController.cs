using JoyJoey.Combat.Actions;
using JoyJoey.Combat.Attacks;
using JoyJoey.Core;
using JoyJoey.Core.Abilities;
using JoyJoey.Player.Input;
using JoyJoey.Player.Rags;
using UnityEngine;

namespace JoyJoey.Player.Combat
{
    [RequireComponent(typeof(PlayerController))]
    public class PlayerCombatController : MonoBehaviour
    {
        [SerializeField] private PlayerController controller;
        [SerializeField] private AttackExecutor attackExecutor;
        [SerializeField] private AbilityUnlockManager abilityManager;
        [SerializeField] private RagManager ragManager;

        [Header("Default Normal Actions")]
        [SerializeField] private ActionSet groundNormalActions;
        [SerializeField] private ActionSet airNormalActions;

        [Header("Fallbacks (when suit lacks overrides)")]
        [SerializeField] private ActionSet transformedNormalFallback;

        private void Reset()
        {
            controller = GetComponent<PlayerController>();
        }

        private void Awake()
        {
            controller ??= GetComponent<PlayerController>();
            abilityManager ??= GetComponent<AbilityUnlockManager>();
            ragManager ??= GetComponent<RagManager>();
            attackExecutor ??= GetComponentInChildren<AttackExecutor>();
        }

        public bool TryHandleInput(InputSignature signature)
        {
            if (!IsActionButton(signature.Button))
            {
                return false;
            }

            if (attackExecutor == null)
            {
                return false;
            }

            var attack = ResolveAttack(signature);
            if (attack == null)
            {
                return false;
            }

            attackExecutor.PlayAttack(attack);

            if (attack.consumeDashCarry)
            {
                controller.ConsumeDashCarryFlag();
            }

            return true;
        }

        private AttackData ResolveAttack(in InputSignature signature)
        {
            var direction = DetermineDirection(signature);
            var context = controller.MovementContext;

            return signature.Button switch
            {
                InputButton.Normal => ResolveNormalAction(direction, context, signature.IsTransformed),
                InputButton.SpecialAttack => ResolveSpecialAttack(direction, context, signature.IsTransformed),
                InputButton.SpecialSkill => ResolveSpecialSkill(direction, context, signature.IsTransformed),
                _ => null,
            };
        }

        public void OnMovementContextChanged(MovementContext context)
        {
            // Hook reserved for future context-specific behaviour (e.g., resetting combo routes)
        }

        private AttackData ResolveNormalAction(ActionDirection direction, MovementContext context, bool isTransformed)
        {
            ActionSet actionSet = null;

            if (isTransformed)
            {
                var rag = ragManager != null ? ragManager.CurrentRag : null;
                if (rag != null)
                {
                    actionSet = GetContextualSet(rag.SuitNormalGroundActions, rag.SuitNormalAirActions, context);
                }

                if (actionSet == null)
                {
                    actionSet = GetContextualSet(transformedNormalFallback, transformedNormalFallback, context);
                }
            }

            if (actionSet == null)
            {
                actionSet = GetContextualSet(groundNormalActions, airNormalActions, context);
            }

            return actionSet != null ? actionSet.Resolve(direction, abilityManager) : null;
        }

        private AttackData ResolveSpecialAttack(ActionDirection direction, MovementContext context, bool isTransformed)
        {
            var rag = ragManager != null ? ragManager.CurrentRag : null;
            if (rag == null)
            {
                return null;
            }

            var set = GetContextualSet(rag.SpecialAttackGroundActions, rag.SpecialAttackAirActions, context);
            return set != null ? set.Resolve(direction, abilityManager) : null;
        }

        private AttackData ResolveSpecialSkill(ActionDirection direction, MovementContext context, bool isTransformed)
        {
            var rag = ragManager != null ? ragManager.CurrentRag : null;
            if (rag == null)
            {
                return null;
            }

            var set = GetContextualSet(rag.SpecialSkillGroundActions, rag.SpecialSkillAirActions, context);
            return set != null ? set.Resolve(direction, abilityManager) : null;
        }

        private static ActionSet GetContextualSet(ActionSet groundSet, ActionSet airSet, MovementContext context)
        {
            if (context == MovementContext.Air)
            {
                return airSet != null ? airSet : groundSet;
            }

            return groundSet != null ? groundSet : airSet;
        }

        private static ActionDirection DetermineDirection(in InputSignature signature)
        {
            if (signature.DirY == -1)
            {
                return ActionDirection.Down;
            }

            if (signature.DirX != 0)
            {
                return ActionDirection.Horizontal;
            }

            return ActionDirection.Neutral;
        }

        private static bool IsActionButton(InputButton button)
        {
            return button == InputButton.Normal || button == InputButton.SpecialAttack || button == InputButton.SpecialSkill;
        }
    }
}
