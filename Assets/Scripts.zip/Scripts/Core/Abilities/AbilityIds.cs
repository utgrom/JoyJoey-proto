namespace JoyJoey.Core.Abilities
{
    public static class AbilityIds
    {
        public const string None = "None";

        // Core movement abilities
        public const string Jump = "movement.jump";
        public const string AirJump = "movement.airJump";
        public const string Dash = "movement.dash";
        public const string AirDash = "movement.airDash";
        public const string WallJump = "movement.wallJump";

        public static class Rag
        {
            public static class Strongman
            {
                public const string Unlock = "rag.strongman.unlock";
                public const string Transform = "suit.strongman.transform";
                public const string NormalNeutral = "strongman.normal.neutral";
                public const string SpecialAttackDown = "strongman.specialAttack.down";
                public const string SpecialSkillNeutral = "strongman.specialSkill.neutral";
            }

            public static class Balloon
            {
                public const string Unlock = "rag.balloon.unlock";
                public const string Transform = "suit.balloon.transform";
            }

            public static class Jester
            {
                public const string Unlock = "rag.jester.unlock";
                public const string Transform = "suit.jester.transform";
            }
        }
    }
}
