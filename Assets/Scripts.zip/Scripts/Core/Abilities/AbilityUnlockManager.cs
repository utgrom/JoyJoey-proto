﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace JoyJoey.Core.Abilities
{
    public class AbilityUnlockManager : MonoBehaviour
    {
        [Serializable]
        private class AbilityState
        {
            public string abilityId = AbilityIds.None;
            public bool unlocked = false;
            public int level = 0;
        }

        [SerializeField] private List<AbilityState> abilities = new List<AbilityState>();

        private readonly Dictionary<string, AbilityState> _lookup = new Dictionary<string, AbilityState>();

        public event Action<string, int> AbilityUnlocked;
        public event Action<string, int> AbilityLevelChanged;

        private void Awake()
        {
            _lookup.Clear();
            foreach (var state in abilities)
            {
                if (!_lookup.ContainsKey(state.abilityId) && state.abilityId != AbilityIds.None)
                {
                    _lookup.Add(state.abilityId, state);
                }
            }
        }

        public bool CanUse(string abilityId)
        {
            if (string.IsNullOrEmpty(abilityId) || abilityId == AbilityIds.None)
            {
                return true;
            }

            return _lookup.TryGetValue(abilityId, out var state) && state.unlocked;
        }

        public int GetLevel(string abilityId)
        {
            return _lookup.TryGetValue(abilityId, out var state) ? state.level : 0;
        }

        public void Unlock(string abilityId, int level = 1)
        {
            if (!_lookup.TryGetValue(abilityId, out var state))
            {
                state = new AbilityState { abilityId = abilityId };
                abilities.Add(state);
                _lookup.Add(abilityId, state);
            }

            if (!state.unlocked || state.level < level)
            {
                state.unlocked = true;
                state.level = level;
                AbilityUnlocked?.Invoke(abilityId, state.level);
            }
        }

        public void SetLevel(string abilityId, int level)
        {
            if (!_lookup.TryGetValue(abilityId, out var state))
            {
                return;
            }

            level = Mathf.Max(level, 0);

            if (state.level != level)
            {
                state.level = level;
                AbilityLevelChanged?.Invoke(abilityId, state.level);
            }
        }
    }
}
