﻿using System;

namespace JoyJoey.Core
{
    [Flags]
    public enum InputModifiers
    {
        None = 0,
        Tap = 1 << 0,
        Hold = 1 << 1,
    }

    public enum InputButton
    {
        None = 0,
        Normal = 1,
        SpecialAttack = 2,
        SpecialSkill = 3,
        Jump = 4,
        Dash = 5,
        Transform = 6,
        SwapNext = 7,
        SwapPrevious = 8,
    }

    public enum MovementContext
    {
        Ground = 0,
        Air = 1,
        Wall = 2,
    }

    [Flags]
    public enum InputContextFlags
    {
        None = 0,
        DashCarry = 1 << 0,
    }

    public enum InputActionId
    {
        None = 0,
        Jump = 1,
        Dash = 2,
        Transform = 3,
        Normal = 4,
        SpecialAttack = 5,
        SpecialSkill = 6,
        SwapNext = 7,
        SwapPrevious = 8,
    }

    public enum ActionPriority
    {
        Low = 0,
        Normal = 1,
        High = 2,
        VeryHigh = 3,
    }

    public enum PreemptionType
    {
        Soft = 0,
        Hard = 1,
    }

    [Flags]
    public enum InputBufferConsumeCondition
    {
        None = 0,
        OnWindowOpen = 1 << 0,
        OnLand = 1 << 1,
        OnNeutral = 1 << 2,
        OnTimeout = 1 << 3,
    }

    public enum MomentumPolicy
    {
        Maintain = 0,
        BlendTo = 1,
        ZeroOnEnter = 2,
        ZeroOnExit = 3,
    }

    public enum ReactionTier
    {
        NoFlinch = 0,
        Flinch = 1,
        Stagger = 2,
        Launch = 3,
        Knockdown = 4,
    }

    public enum ActionDirection
    {
        Neutral = 0,
        Horizontal = 1,
        Down = 2,
    }
}
