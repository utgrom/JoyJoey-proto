using System;
using UnityEngine;

namespace JoyJoey.Core
{
    [Serializable]
    public class MovementStats
    {
        public float maxGroundSpeed = 7f;
        public float groundAcceleration = 50f;
        public float groundDeceleration = 60f;
        public float airAcceleration = 30f;
        public float airDeceleration = 20f;
    }

    [Serializable]
    public class JumpStats
    {
        public float jumpVelocity = 12f;
        public int maxAirJumps = 0;
        public float coyoteTime = 0.1f;
        public float gravityScale = 1f;
        public float maxFallSpeed = 18f;
        public float wallJumpHorizontalSpeed = 10f;
        public float wallJumpVerticalSpeed = 12f;
        [Header("Variable Jump")]
        public float maxJumpHoldTime = 0.2f;     // seconds of sustained upward velocity
                public float fallGravityMultiplier = 2f;       // gravityScale multiplier while descending
        public float jumpCutGravityMultiplier = 2.5f;  // gravityScale multiplier when jump released while ascending
    }

    [Serializable]
    public class DashStats
    {
        public float dashSpeed = 14f;
        public float startupTime = 0.05f;
        public float activeTime = 0.12f;
        public float recoveryTime = 0.05f;
        public MomentumPolicy momentumPolicy = MomentumPolicy.Maintain;
        public bool locksInputs = true;
        public bool carryMomentum = true;
        public float carryWindow = 0.15f;

        public float TotalDuration => Mathf.Max(0f, startupTime + activeTime + recoveryTime);
    }

    [CreateAssetMenu(menuName = "JoyJoey/Stats/Player Stats Profile", fileName = "PlayerStatsProfile")]
    public class PlayerStatsProfile : ScriptableObject
    {
        public MovementStats movement = new MovementStats();
        public JumpStats jump = new JumpStats();
        public DashStats dash = new DashStats();

        public PlayerRuntimeStats CreateRuntimeInstance()
        {
            return new PlayerRuntimeStats
            {
                movement = JsonUtility.FromJson<MovementStats>(JsonUtility.ToJson(movement)),
                jump = JsonUtility.FromJson<JumpStats>(JsonUtility.ToJson(jump)),
                dash = JsonUtility.FromJson<DashStats>(JsonUtility.ToJson(dash)),
            };
        }
    }

    [Serializable]
    public class PlayerRuntimeStats
    {
        public MovementStats movement = new MovementStats();
        public JumpStats jump = new JumpStats();
        public DashStats dash = new DashStats();

        public PlayerRuntimeStats Clone()
        {
            return new PlayerRuntimeStats
            {
                movement = JsonUtility.FromJson<MovementStats>(JsonUtility.ToJson(movement)),
                jump = JsonUtility.FromJson<JumpStats>(JsonUtility.ToJson(jump)),
                dash = JsonUtility.FromJson<DashStats>(JsonUtility.ToJson(dash)),
            };
        }
    }
}


